#include<stdio.h>
int main() {
	int length;
	int arr[32] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32 };
	
	int arr2[32], i, sub_i;
	srand((unsigned int)time(NULL));
	for (i = 0; i < 32; i++) {
		arr2[i] = rand() % 32 + 1;
		for (sub_i = 0; sub_i < i; sub_i++) {
			if (arr2[i] == arr2[sub_i]) {
				i--;
				break;
			}
		}
	}
	for (i = 0; i < 32; i++);

	length = sizeof(arr) / sizeof(int);

	insertion_sort_Sorted(arr, length);

	COMPARE(insertion_sort_Sorted, insertion_sort_Random);

	return 0;
}

//��������_(1)Sorted
void insertion_sort_Sorted(int arr[], int length) {
	int i, j, key, tmp;

	for (j = 1; j < length; j++) {
		key = arr[j];
		i = j - 1;
		while (i >= 0 && arr[i] >= key) {
			arr[i + 1] = arr[i];
			i = i - 1;
		}
		arr[i + 1] = key;
	}
}

//��������_(2)Random
void insertion_sort_Random(int arr2[], int length) {
	int i, j, key, tmp;

	for (j = 1; j < length; j++) {
		key = arr2[j];
		i = j - 1;
		while (i >= 0 && arr2[i] >= key) {
			arr2[i + 1] = arr2[i];
			i = i - 1;
		}
		arr2[i + 1] = key;
	}
}